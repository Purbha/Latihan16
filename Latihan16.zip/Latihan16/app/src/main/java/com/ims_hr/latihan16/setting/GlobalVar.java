package com.ims_hr.latihan16.setting;

public class GlobalVar {

    public static final String EXTRA_NAMA = "nama";
    public static final String EXTRA_ROLE = "role";
    public static final String EXTRA_DESC = "desc";
    public static final String EXTRA_RATING = "rating";
    public static final String EXTRA_GAMBAR = "gambar";

}
